CREATE DEFINER=`root`@`%` PROCEDURE `spNoLoginMember_check`( -- demon.zplab 에서 스케쥴러로 호출 실행됨.
  _job 		varchar(100) 	-- dormant30(오늘 기준, 휴면회원 되기 30일 전 회원 list)
                        -- dormant(오늘 기준, 휴면회원 대상 list)
                        -- dormant_cancel(hcpApproval === Approved && isDormant === 1 이면서 어제 로그인한 회원 전체 대상 isDormant = 0 으로 업데이트)
                        -- dormant_update(휴면회원 전환 알림 이메일 발송 후 휴면회원으로 처리) 

  ,_userPK 	int	        -- dormant_update(휴면회원 전환 알림 이메일 발송 후 휴면회원으로 처리할 users.id 대상 isDormant = 1 로 업데이트)     
   
)
THIS_PROC : BEGIN
/* 
call spNoLoginMember_check('dormant30',null);
call spNoLoginMember_check(
  @_job := 'dormant30',
  @_userPK := null
);
 */

  /****** job 구분하여 로직 실행 ******/
  
  /** dormant30(오늘 기준, 휴면회원 되기 30일 전 회원 list) **/ 
  /** dormant(오늘 기준, 휴면회원 대상 list) **/
	if _job in ('dormant30', 'dormant') then 
    SELECT 
        a.userPK,
        b.`name`,
        b.email,
        b.hcpApproval,
        -- a.`level`,
        -- a.`datetime`,
        -- max(a.`datetime`),
        -- date_format(max(a.`datetime`), '%Y-%m-%d %H:%i:%s') as last_login_datetime,
        date_format(max(a.`datetime`), '%Y-%m-%d') as last_login_date,
        date_format(date_add(max(a.`datetime`), interval 335 day), '%Y-%m-%d') as login_335_date,
        date_format(date_add(max(a.`datetime`), interval 1 year), '%Y-%m-%d') as login_365_date
    FROM userlogs a 
    join users b on a.userPK = b.id

    where 1=1
        and a.`level`in ('Success', 'SignUp') -- 로그인 성공 및 회원가입 완료 (로직 조건 추가 : 회원가입 후 로그인하지 않은 사용자포함)
        and b.roles = 'member' -- 관리자(admin) 제외
        and b.hcpApproval = 'Approved' -- 승인된 회원
        and b.isDormant = 0 -- 휴면 처리되지 않은 회원

    GROUP by 
        a.userPK,
        b.`name`,
        b.email,
        b.hcpApproval
        -- ,a.`level`
    
    HAVING date_format(now(), '%Y-%m-%d') = case _job when 'dormant30' then login_335_date 
                                                      when 'dormant' then login_365_date 
                                            end
    ; -- GO

    leave THIS_PROC; 





  /** dormant_cancel(hcpApproval === Approved && isDormant === 1 이면서 어제 로그인한 회원 전체 대상 isDormant = 0 으로 일괄 업데이트) **/ 
  elseif _job in ('dormant_cancel') then 

    UPDATE users
        SET isDormant = 0 -- 휴면회원 해제
    WHERE 1=1
        and isDormant = 1
        and roles = 'member' 
        and hcpApproval = 'Approved' 
        and id in ( -- 오늘 로그인한 사용자 대상
              select 
                DISTINCT userPK 
              from userlogs 
              where `level` = 'Success' 
                and date_format(date_add(now(), interval -1 day), '%Y-%m-%d') = date_format(`datetime`, '%Y-%m-%d') -- 어제 로그인한 사용자
          )
    ; -- GO

    select 0 as result, 'dormant_cancel ended' as result_message, ROW_COUNT() as result_count;
    leave THIS_PROC; 





  /** dormant_update(휴면회원 전환 알림 이메일 발송 후 휴면회원으로 처리) **/ 
  elseif _job in ('dormant_update') then 

    UPDATE users
        SET isDormant = 1 -- 휴면회원
    WHERE 1=1
        and id = _userPK
        and isDormant = 0
        and roles = 'member' 
        and hcpApproval = 'Approved' 
    ; -- GO


    select 0 as result, 'dormant_update ended' as result_message, ROW_COUNT() as result_count, _userPK as result_userPK;
    leave THIS_PROC; 

  end if;


/* 
  DROP PROCEDURE IF EXISTS spNoLoginMember_check;
*/

END
