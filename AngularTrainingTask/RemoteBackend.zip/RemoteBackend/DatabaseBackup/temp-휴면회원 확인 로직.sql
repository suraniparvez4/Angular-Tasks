-- set @userPK = 69;

-- SELECT 
-- a.userPK,
-- b.`name`,
-- b.email,
-- b.hcpApproval,
-- a.`level`,
-- -- a.`datetime`,
-- -- max(a.`datetime`),
-- date_format(max(a.`datetime`), '%Y-%m-%d %H:%i:%s') as last_login_datetime,
-- date_format(max(a.`datetime`), '%Y-%m-%d') as last_login_date,
-- date_format(date_add(max(a.`datetime`), interval 335 day), '%Y-%m-%d') as login_335_date,
-- date_format(date_add(max(a.`datetime`), interval 1 year), '%Y-%m-%d') as login_365_date
-- FROM userlogs a 
-- join users b on a.userPK = b.id

-- where 1=1
-- -- and a.userPK = @userPK
-- and b.roles = 'member'
-- and b.hcpApproval = 'Approved'
-- and a.`level`= 'Success'

-- GROUP by 
-- a.userPK,
-- b.`name`,
-- b.email,
-- b.hcpApproval,
-- a.`level`

-- ORDER BY `datetime` desc

set @_job = 'dormant30';
SELECT 
    a.userPK,
    b.`name`,
    b.email,
    b.hcpApproval,
    -- a.`level`,
    -- a.`datetime`,
    -- max(a.`datetime`),
    date_format(max(a.`datetime`), '%Y-%m-%d %H:%i:%s') as last_login_datetime,
    date_format(max(a.`datetime`), '%Y-%m-%d') as last_login_date,
    date_format(date_add(max(a.`datetime`), interval 1 day), '%Y-%m-%d') as login_335_date, -- for test : interval 335 day 
    date_format(date_add(max(a.`datetime`), interval 1 year), '%Y-%m-%d') as login_365_date
FROM userlogs a 
join users b on a.userPK = b.id

where 1=1
    and a.`level` in ('Success', 'SignUp') 
    and b.roles = 'member' 
    and b.hcpApproval = 'Approved' 
    and b.isDormant = 0 

GROUP by 
    a.userPK,
    b.`name`,
    b.email,
    b.hcpApproval
    -- a.`level`

HAVING date_format(now(), '%Y-%m-%d') = case @_job when 'dormant30' then login_335_date -- date_format(date_add(max(a.`datetime`), interval 335 day), '%Y-%m-%d') 
                                                   when 'dormant' then login_365_date -- date_format(date_add(max(a.`datetime`), interval 1 year), '%Y-%m-%d')
                                        end
