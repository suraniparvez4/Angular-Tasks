### API Endpoints
| endpoint | Description | Request Format | Request Parameters | Parameter Description | Remarks |
| -------- | ----------- | -------------- | ------------------ | --------------------- | ------- |
|/api/users|To register user|POST|data:{data : `user info`\*\*}|Signup object which contain all details and roles:"member" for signup|---|
|/api/users/updatePW|To update password (비밀번호 변경)|PUT|data:{id,password}|---|---|
|/api/users/cancelMembership/:id|To cancel membership (회원탈퇴)|DELETE|id|---|---|
|/api/users/userCheck|To check email exist in table, if exist than return member|POST|data:{username}|Passing email|---|
|/api/users/loginCounter|For incorrect login attempts|POST|data:{id,loginCount}|Passing user's id and failed login attempt count|---|
|/api/users/emailSent|To update user and sent an Email|POST|data:{id,email,password}|Passing user's id,email and password|---|
|/api/users/findId|To find user's email|POST|data:{username,licenseNumber}|Passing username and licenseNumber|---|
|/api/users/findPassword|To find user's password|POST|data:{username,email}|Passing username and email|---|
|/api/users|To retrieve all members list|GET|---|---|---|
|/api/users/:id|To retrieve single member|GET|id|passing id|---|
|/api/users/:id|To update member|PUT|id,data:{id,username,password}|id=for single record,data=pass id,username and password|---|
|/api/users/:id|To delete single member|DELETE|id|id=for single record|---|
|/api/users/:id|To delete members|DELETE|---|---|---|
|/api/users/memberLoginPage|For member login intial page|POST|data:{email,password}|---|---|
|/api/members|To get all members list|GET|---|---|
|/api/members/findbyNameDate|To get filtered member list by Name and Date|POST|data:{name,startDate,endDate}|username,date filter for createdDate|--|
|/api/members/:id|To get single record by id|GET|id|userid|---|
|api/members/|To update member record|PUT|id,data : `user info`\*\*}|id and member details to update|--|
|/api/members/:id|To delete single member|DELETE|id|user's id|---|
|api/members|To delete all members|DELETE|---|---|---|
|/api/login|To validate member and login|POST|data:{id,username,password}|id,username and password to validate|---|
|/api/adminlogin|To validate admin and login|POST|data:{id,username,password}|id,username and password to validate|---|
|/api/logout|To logout member and admin|GET|---|---|---| 

## `user info`\*\*
```
{name,email,password,birth,hcpApproval,roles,licenseType,licenseNumber,
isFullyAgree,isTermsandConditions,isUseofPersonalInfo,isProcessPersonalInfo,
isDeliveringMedicalAndPharmaceuticalInfo}
```
