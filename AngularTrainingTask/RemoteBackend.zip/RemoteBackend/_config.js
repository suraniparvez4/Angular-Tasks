// `_config.js.sample` >> `_config.js` 파일명 변경 

const MAILCON = {
    url : "https://api.zplab.co.kr/gilead_hcp/sendmail",
    apiKey : "<apiKey>",
    managerEmail : "nh2.kim@predict.kr" 
}

module.exports = {
    MAILCON
};
