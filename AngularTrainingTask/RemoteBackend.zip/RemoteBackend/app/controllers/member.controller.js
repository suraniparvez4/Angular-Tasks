const db = require("../models");
const Member = db.members;
const User = db.users;
const seq = require("../models/index.js");
const Op = db.Sequelize.Op;
const passwordEncDescService = require("./passwordEncDesc.controller");

const { MAILCON } = require('../../_config');
const axios = require('axios');
const moment = require('moment');

// Create
// exports.create = (req, res) => {
//   // Validate request
//   if (!req.body.title) {
//     res.status(400).send({
//       message: "Content can not be empty!"
//     });
//     return;
//   }

//   // Create
//   const member = {
//     title: req.body.title,
//     description: req.body.description,
//     published: req.body.published ? req.body.published : false
//   };

//   // Save
//   Member.create(member)
//     .then(data => {
//       res.send(data);
//     })
//     .catch(err => {
//       res.status(500).send({
//         message:
//           err.message || "Some error occurred while creating."
//       });
//     });
// };

// Find all

// 회원가입통계
exports.signUpCount = (req, res) => {
  //통계타입 type : sum / term
  //통계시작일자 startDate : yyyy-mm-dd
  //통계종료일자 endDate : yyyy-mm-dd

  const nowDateTime = moment().format();
  const nowDate = moment().format('YYYY-MM-DD');
  const startDate = req.query.startDate || moment().format('YYYY-MM-DD');
  const endDate = req.query.endDate || moment().format('YYYY-MM-DD');

  console.log(nowDateTime, startDate, endDate);

  seq.sequelize.query(`-- signUpCount
    select 
      date_format('${nowDateTime}', '%Y-%m-%d %H:%i:%s') as now, 
      '${startDate}' as startDate,
      '${endDate}' as endDate,

      (select 
        count(id) as count_users
        from users) as allSignUpCount,

      (select 
        count(id) as count_users
        from users 
        where date_format(createdAt, '%Y-%m-%d') = '${nowDate}') as todaySignUpCount,
    
      (select 
        count(id) as count_users
        from users 
        where date_format(createdAt, '%Y-%m-%d') between '${startDate}' and '${endDate}') as termSignUpCount;

  `).then(results => {
    // 요청사항 : query.startDate 와 query.endDate 모두 빈값이면 termSignUpCount >> allSignUpCount 값으로 대체
    if (!req.query.startDate && !req.query.endDate) {
      results[0][0].termSignUpCount = results[0][0].allSignUpCount
    }

    res.send(results[0]);
  });
  /* sample
  /api/members/signUpCount (startDate, endDate 없으면 모두 now로 초기화)
  /api/members/signUpCount?startDate=2022-10-01&endDate=2022-12-30

  [
    {
      "now": "2022-12-29 12:24:48",
      "startDate": "2022-10-01",
      "endDate": "2022-12-30",
      "allSignUpCount": 11,
      "todaySignUpCount": 1,
      "termSignUpCount": 10
    }
  ]
   */
};

// 회원로그인통계
exports.logInCount = (req, res) => {
  //통계타입 type : sum / term
  //통계시작일자 startDate : yyyy-mm-dd
  //통계종료일자 endDate : yyyy-mm-dd

  const nowDateTime = moment().format();
  const nowDate = moment().format('YYYY-MM-DD');
  const startDate = req.query.startDate || moment().format('YYYY-MM-DD');
  const endDate = req.query.endDate || moment().format('YYYY-MM-DD');

  console.log(nowDateTime, startDate, endDate);

  seq.sequelize.query(`-- logInCount
    select 
      date_format('${nowDateTime}', '%Y-%m-%d %H:%i:%s') as now, 
      '${startDate}' as startDate,
      '${endDate}' as endDate,

      (select 
        count(id) as count_login
        from userlogs 
        where \`level\` = 'Success') as allLogInCount,

      (select 
        count(id) as count_login
        from userlogs 
        where \`level\` = 'Success'
        and date_format(\`datetime\`, '%Y-%m-%d') = '${nowDate}') as todayLogInCount,
      
      (select 
        count(id) as count_login
        from userlogs 
        where \`level\` = 'Success'
        and date_format(\`datetime\`, '%Y-%m-%d') between '${startDate}' and '${endDate}') as termLogInCount;

  `).then(results => {
    // 요청사항 : query.startDate 와 query.endDate 모두 빈값이면 termLogInCount >> allLogInCount 값으로 대체
    if (!req.query.startDate && !req.query.endDate) {
      results[0][0].termLogInCount = results[0][0].allLogInCount
    }

    res.send(results[0]);
  });
  /* sample
  /api/members/logInCount (startDate, endDate 없으면 모두 now로 초기화)
  /api/members/logInCount?startDate=2022-10-01&endDate=2022-12-30

[
  {
    "now": "2022-12-29 11:48:10",
    "startDate": "2022-10-01",
    "endDate": "2022-12-30",
    "allLogInCount": 71,
    "todayLogInCount": 2,
    "termLogInCount": 70
  }
]
  */
};

exports.findAll = (req, res) => {
  // const name = req.query.name;
  //var condition = name ? { name: { [Op.like]: `%${name}%` } } : null;

  // Member.findAll({ where: condition })
  //   .then(data => {
  //     res.send(data);
  //   })
  //   .catch(err => {
  //     res.status(500).send({
  //       message:
  //         err.message || "Some error occurred while retrieving."
  //     });
  //   });

  Member.findAll({ where: { roles: { [Op.not]: 'admin' } } })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving."
      });
    });
};


//Find by Name Date
exports.findbyNameDate = (req, res) => {
  const name = req.body.name;
  var startDate = req.body.startDate
  // var startDateYear = startDate.getFullYear()
  // var startDateMonth = startDate.getMonth()
  // var startDateDay = startDate.getDate()
  var endDate = req.body.endDate

  // var test = startDateYear + "-" + startDateMonth + "-" + startDateDay + " " + "00:00:00";
  // console.error("Date is : " + new Date(startDateYear, startDateMonth, startDateDay))
  var nameCondition = name ? { name: { [Op.like]: `%${name}%` } } : null;
  console.error("nameCondition is : " + name)
  if (startDate) {
    startDate = new Date(startDate)
    startDate = startDate.toISOString()

    endDate = new Date(endDate)
    endDate.setHours(29, 29, 59, 0);//GMT Format+23:59:59 for Day End
    endDate = endDate.toISOString()
    if (name) {
      console.error("name is : ")
      Member.findAll({ where: { [Op.and]: [{ name: { [Op.like]: `%${name}%` } }, { createdAt: { [Op.gte]: startDate, [Op.lte]: endDate } }, { roles: { [Op.not]: "admin" } }] } })
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message:
              err.message || "Some error occurred while retrieving."
          });
        });
    }
    else {
      console.error("name else is : ")
      Member.findAll({ where: { [Op.and]: [{ createdAt: { [Op.gte]: startDate, [Op.lte]: endDate } }, { roles: { [Op.not]: "admin" } }] } })
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message:
              err.message || "Some error occurred while retrieving."
          });
        });
    }
  }
  else {
    if (name) {
      console.error("else name is : ")
      Member.findAll({ where: { [Op.and]: [{ name: { [Op.like]: `%${name}%` } }, { roles: { [Op.not]: "admin" } }] } })
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message:
              err.message || "Some error occurred while retrieving."
          });
        });
    }
    else {
      console.error("else name else is : ")
      Member.findAll({ where: { roles: { [Op.not]: "admin" } } })
        .then(data => {
          res.send(data);
        })
        .catch(err => {
          res.status(500).send({
            message:
              err.message || "Some error occurred while retrieving."
          });
        });
    }
  }
};


// Find with id
exports.findOne = (req, res) => {
  const id = req.params.id;

  Member.findByPk(id)
    .then(data => {
      if (data) {
        // console.error("PASSWORD IS : "+data.password)
        data.password = passwordEncDescService.decryptRequest(data.password);
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find with id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with id=" + id
      });
    });
};

// Update by the id 
exports.update = (req, res) => {
  const id = req.params.id;
  const updateType = req.params.updateType;

  console.log('req.params --- ', req.body);

  req.body.password = passwordEncDescService.encryptRequest(req.body.password);
  User.findOne({ where: { licenseNumber: req.body.licenseNumber, id: { [Op.not]: id }, roles: { [Op.eq]: 'member' } } })
    .then(data => {
      console.log("In LicenseNumber " + data)
      if (data != "" && data != null) {
        console.log("In LicenseNumber " + data)
        res.send("LicenseNumber Already Exists");
      } else {
        console.log("In true")
        Member.update(req.body, {
          where: { id: id }
        })
          .then(num => {
            if (num == 1) {
              // 업데이트 사용자의 이메일 주소 사용가능?
              console.log('email ---- ', req.body.email);

              // 메일전송 API (구현 참조 : was2.zplab.co.kr/server/api/MetaverseUser/contactus/contactus.ctrl.js)
              // 7. 관리자 페이지에서 승인 시 -> 사용자에게 승인 완료 알림메일 발송됨
              // https://github.com/predict-interactive/Gilead-HCP-front/issues/2#issuecomment-1341947564
              const sendMail_approved = () => {
                const receiveEmail = req.body.email;

                axios.post(MAILCON.url, {
                  apiKey: MAILCON.apiKey,
                  gubun: "approved",
                  data: {
                    receiveEmail,
                    managerEmail: MAILCON.managerEmail
                  }
                }).then((res) => {
                  console.log(res.data)
                  console.log('승인 - 메일전송완료');
                })
              }

              // 6. 관리자 페이지에서 미승인 시 -> 담당자에게 미승인 사유가 포함된 메일이 발송됨
              const sendMail_unapproved = () => {
                const receiveEmail = MAILCON.managerEmail; // 회원에게는 메일 보내지 않음 - req.email; 

                let message = req.body.hcpApproval;
                switch (req.body.hcpApproval) {
                  case 'Name discrepancy':
                    message = '성명 불일치';
                    break;
                  case 'License number mismatch':
                    message = '면허번호 불일치';
                    break;
                  case 'Birth date mismatch':
                    message = '생년월일 불일치';
                    break;
                }

                axios.post(MAILCON.url, {
                  apiKey: MAILCON.apiKey,
                  gubun: "unapproved",
                  data: {
                    receiveEmail,
                    managerEmail: MAILCON.managerEmail,
                    memberName: req.body.name, // 회원이름 추가
                    text: message // 메시지 내용 한글 변환 적용
                  }
                }).then((res) => {
                  console.log(res.data)
                  console.log('미승인 - 메일전송완료');
                })
              }

              console.log("Before Mail : " + " " + updateType);
              if (updateType == 'viewLicense') {
                console.log("In Mail");
                // 회원 정보 업데이트 성공 >> 승인시 (hcpApproval = Approved)
                if (req.body.hcpApproval === 'Approved') {
                  sendMail_approved(); // 7. 관리자 페이지에서 승인 시 -> 사용자에게 승인 완료 알림메일 발송됨
                }
                // 회원 정보 업데이트 성공 >> 미승인시 (hcpApproval <> Approved / hcpApproval <> Waiting for approval )
                else if (req.body.hcpApproval !== 'Approved' && req.body.hcpApproval !== 'Waiting for approval') {
                  sendMail_unapproved(); // 6. 관리자 페이지에서 미승인 시 -> 담당자에게 미승인 사유가 포함된 메일이 발송됨
                }
              }
              console.log("After Mail");
              res.send({
                message: "Updated successfully."
              });
            } else {
              res.send({
                message: `Cannot update with id=${id}. Maybe content was not found or req.body is empty!`
              });
            }
          })
          .catch(err => {
            res.status(500).send({
              message: "Error updating with id=" + id
            });
          });
        // res.send(true);
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with email=" + email
      });
    });

  // Commented coz have to apply licenseNumber already exist validation
  // Member.update(req.body, {
  //   where: { id: id }
  // })
  //   .then(num => {
  //     if (num == 1) {
  //       res.send({
  //         message: "Updated successfully."
  //       });
  //     } else {
  //       res.send({
  //         message: `Cannot update with id=${id}. Maybe content was not found or req.body is empty!`
  //       });
  //     }
  //   })
  //   .catch(err => {
  //     res.status(500).send({
  //       message: "Error updating with id=" + id
  //     });
  //   });
};

// Delete with id
exports.delete = (req, res) => {
  const id = req.params.id;

  Member.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete with id=${id}. Maybe Content was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete with id=" + id
      });
    });
};

// Delete all
exports.deleteAll = (req, res) => {
  Member.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all."
      });
    });
};

// find all
// exports.findAllPublished = (req, res) => {
//   Member.findAll({ where: { published: true } })
//     .then(data => {
//       res.send(data);
//     })
//     .catch(err => {
//       res.status(500).send({
//         message:
//           err.message || "Some error occurred while retrieving."
//       });
//     });
// };
