const { Console } = require('console');
const crypto = require('crypto');
const dotenv = require('dotenv');
dotenv.config();


const algorithm = 'aes-256-cbc'
// const algorithm = 'aes-256-ecb';
// const key = "7x!A%D*G-JaNdRgUkXp2s5v8y/B?E(H+";

//Solution working for Dynamic Key and iv for algorithm 'aes-128-cbc' 
// const key = crypto.randomBytes(16);
// const iv = crypto.randomBytes(16);

//Solution working for Static Key and iv for algorithm 'aes-256-cbc'
const ENC_KEY = Buffer.from(process.env.PASSWORD_KEY, "hex"); // set random encryption key
const IV = Buffer.from(process.env.PASSWORD_IV, "hex"); // set random initialisation vector

exports.encryptRequest = function (data) {
    // const cipher = crypto.createCipheriv(algorithm, key, iv);
    // const encrypted = Buffer.concat([cipher.update(data), cipher.final()]);
    // console.log({
    //     iv: iv.toString('hex'),
    //     content: encrypted.toString('hex')
    // })
    // return {
    //     iv: iv.toString('hex'),
    //     content: encrypted.toString('hex')
    // };

    // console.error("ENSC IV IS : "+iv)
    // const cipher = crypto.createCipheriv(algorithm, key, iv);

    // // encrypt the message
    // // input encoding
    // // output encoding
    // let encryptedData = cipher.update(data, "utf-8", "hex");

    // encryptedData += cipher.final("hex");
    // return encryptedData;


    //Solution working for Dynamic Key and iv
    // console.error("Key is the : "+key)
    // var cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
    // var encrypted = cipher.update(data);
    // var finalBuffer = Buffer.concat([encrypted, cipher.final()]);
    // //Need to retain IV for decryption, so this can be appended to the output with a separator (non-hex for this example)
    // var encryptedHex = iv.toString('hex') + ':' + key.toString('hex') + ':' + finalBuffer.toString('hex')
    // return encryptedHex;

    console.log("ENC IS : " + process.env.PASSWORD_KEY + " " + process.env.PASSWORD_IV)
    //Solution working for Static Key and iv
    let cipher = crypto.createCipheriv(algorithm, ENC_KEY, IV);
    let encrypted = cipher.update(data, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
}

exports.decryptRequest = function (text) {
    // try {
    //     const decipher = crypto.createDecipheriv(algorithm, key, text.iv);
    //     const decrpyted = Buffer.concat([decipher.update(text.content, 'base64'), decipher.final()]);
    //     return decrpyted.toString();
    // } catch (error) {

    //     throw error;
    // }

    // console.error("DESC IV IS : " + iv.toString("hex"))
    // const decipher = crypto.createDecipheriv(algorithm, key, iv);

    // let decryptedData = decipher.update(text, "hex", "utf-8");

    // decryptedData += decipher.final("utf8");
    // return decryptedData;



    //Solution working for Dynamic Key and iv
    // var encryptedArray = text.split(':');
    // var ivv = new Buffer(encryptedArray[0], 'hex');
    // var keyy = new Buffer(encryptedArray[1], 'hex');
    // var encrypted = new Buffer(encryptedArray[2], 'hex');
    // var decipher = crypto.createDecipheriv('aes-128-cbc', keyy, ivv);
    // var decrypted = decipher.update(encrypted);
    // var clearText = Buffer.concat([decrypted, decipher.final()]).toString();
    // return clearText;


    //Solution working for Static Key and iv
    let decipher = crypto.createDecipheriv(algorithm, ENC_KEY, IV);
    let decrypted = decipher.update(text, 'base64', 'utf8');
    return (decrypted + decipher.final('utf8'));
}