const db = require("../models");
const User = db.users;
const userlogs = db.userlogs;
const seq = require("../models/index.js");
const Op = db.Sequelize.Op;
var nodemailer = require('nodemailer');
const passwordEncDescService = require("./passwordEncDesc.controller");
const dotenv = require('dotenv');
dotenv.config();

const { MAILCON } = require('../../_config');
const axios = require('axios');
const jwt = require('jsonwebtoken');

// server.js 214 줄 코드 복제 (중복)
function postuserLogs(logs) {
  console.error("In Logs");
  userlogs.create(logs)
    .then(data => {
      console.log("Logs Success : " + data)
    })
    .catch(err => {
      console.log("Logs Error : " + err)
    });
}

// Create
exports.create = async (req, res) => {
  // Validate request
  if (!req.body.name) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
    return;
  }
  console.log("PASSWORD IS : " + req.body.password)
  var encpassword = passwordEncDescService.encryptRequest(req.body.password);
  console.log("ENC Password IS : " + encpassword);

  var key = await randomNumCheck();
  console.log("key IS : " + key);
  // Create
  const user = {
    id: key,
    name: req.body.name,
    email: req.body.email,
    password: encpassword,
    birth: req.body.birth,
    licenseType: req.body.licenseType,
    licenseNumber: req.body.licenseNumber,
    hcpApproval: req.body.hcpApproval,
    roles: req.body.roles,
    isFullyAgree: req.body.isFullyAgree,
    isTermsandConditions: req.body.isTermsandConditions,
    isUseofPersonalInfo: req.body.isUseofPersonalInfo,
    isProcessPersonalInfo: req.body.isProcessPersonalInfo,
    isDeliveringMedicalAndPharmaceuticalInfo: req.body.isDeliveringMedicalAndPharmaceuticalInfo,
  };

  // 메일전송 API (구현 참조 : was2.zplab.co.kr/server/api/MetaverseUser/contactus/contactus.ctrl.js)
  // 1. 사용자가 회원가입 시 -> 사용자에게 가입메일 발송됨 
  // https://github.com/predict-interactive/Gilead-HCP-front/issues/2#issuecomment-1341947564
  const sendMail = () => {
    const receiveEmail = user.email

    axios.post(MAILCON.url, {
      apiKey: MAILCON.apiKey,
      gubun: "signup",
      data: {
        receiveEmail,
        managerEmail: MAILCON.managerEmail
      }
    }).then((res) => {
      console.log(res.data)
      console.log('메일전송완료');
    })
  }

  // Save
  User.create(user)
    .then(data => {
      // console.log('data.dataValues.id : ',data.dataValues.id); // user.id
      //Logs
      postuserLogs({ userPK: data.dataValues.id, level: "SignUp", datetime: new Date() });
      res.send(data);
      sendMail(); // 1. 사용자가 회원가입 완료 응답 후 메일발송
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating."
      });
    });
};

async function randomNumCheck() {
  return await seq.sequelize.query("SELECT FLOOR(100000+RAND() * 900000) AS random_num FROM `users` u WHERE 'random_num' NOT IN(SELECT id FROM users) LIMIT 1").then(results => {
    return JSON.stringify(results[0][0].random_num);
  });

}

// Update my pw
exports.updateByMyID = async (req, res) => {
  // passport 모듈 user 
  if (req.user === undefined) {
    console.log('index', {logged: false});

    res.status(500).send({
      message: `Error no user!`
    });
    return;
  }
  else{
    console.log('user passport info', {logged: true, useremail: req.user.email, userID: req.user.id});
  }
  // */

  const userID = req.body.id; // req.user.id; // 
  const newPW = passwordEncDescService.encryptRequest(req.body.password);
  
  // 로그인한 사용자(req.user.id)와 요청하는 사용자(req.body.id)의 아이디가 일치하면 다음 진행
  if (req.user.id !== req.body.id) {
    
    res.status(500).send({
      message: `Error another user!`
    });
    return;
  }

  User.update({password : newPW}, {
    where: { id: userID, roles: { [Op.not]: 'admin' } }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Updated successfully."
        });
      } else {
        res.status(500).send({
          message: `Cannot update with id=${id}. Maybe content was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating with id=" + id
      });
    });

};

// Delete my id
exports.deleteByMyID = async (req, res) => {
  // passport 모듈 user 
  if (req.user === undefined) {
    console.log('index', {logged: false});

    res.status(500).send({
      message: `Error no user!`
    });
    return;
  }
  else{
    console.log('user passport info', {logged: true, useremail: req.user.email, userID: req.user.id});
  }
  // */

  const userID = req.params.id; // req.user.id; // body형식으로는 보낼 수 없음.
  
  // 로그인한 사용자(req.user.id)와 요청하는 사용자(req.params.id)의 아이디가 일치하면 다음 진행
  if (req.user.id != req.params.id) {
    
    res.status(500).send({
      message: `Error another user!`
      // (user id 확인용) message: `Error another user! passport id:${req.user.id}, params id:${req.params.id}`
    });
    return;
  }

  User.destroy({
    where: { id: userID, roles: { [Op.not]: 'admin' } }
  })
    .then(num => {
      if (num == 1) {
        console.log('Deleted User ', userID);

        userlogs.destroy({
          where: { userPK: userID} 
        }).then(num=>{

          console.log('Deleted User Login Logs ', num);
          res.send({
            message: "Deleted successfully!"
          });
        })
      } else {
        res.status(500).send({
          message: `Cannot delete with id=${id}. Maybe Content was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete with id=" + id
      });
    });
};

// Find all
exports.findAll = (req, res) => {
  const name = req.query.name;
  var condition = name ? { name: { [Op.like]: `%${name}%` } } : null;
  console.error(condition);
  User.findAll({ where: condition, roles: { [Op.eq]: 'member' } })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving."
      });
    });
};

// Find with id
exports.findOne = (req, res) => {
  const id = req.params.id;

  User.findByPk(id)
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find with id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with id=" + id
      });
    });
};

// Update by the id 
exports.update = (req, res) => {
  const id = req.params.id;
  req.body.password = passwordEncDescService.encryptRequest(req.body.password);
  User.update(req.body, {
    where: { id: id, roles: { [Op.not]: 'admin' } }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Updated successfully."
        });
      } else {
        res.send({
          message: `Cannot update with id=${id}. Maybe content was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating with id=" + id
      });
    });
};

// Delete with id
exports.delete = (req, res) => {
  const id = req.params.id;

  User.destroy({
    where: { id: id, roles: { [Op.not]: 'admin' } }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete with id=${id}. Maybe Content was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete with id=" + id
      });
    });
};

// Delete all
exports.deleteAll = (req, res) => {
  User.destroy({
    where: { roles: { [Op.not]: 'admin' } },
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all."
      });
    });
};

//
exports.testAfterLogin = async (req, res) => {
  let token = req.query.token;
  if (!token) {
    token = req.body.token;
  }

  if (!token) {
    res.send("no token");
    return;
  }

  // 아래 샘플 작동 참고용 링크와 동일함.
  // https://jwt.io/#debugger-io?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJIQ1AiOiJZRVMiLCJVc2VySUQiOiJzYW1wbGVVc2VySUQifQ.zYNDMJCaUSx03GB4L6ntcAUxYfeE5UK3di_spplHsdA
  // jwt key
  const SECRET_KEY = 'glieadSecuretyKeySample'; // 테스트용

  const verifyToken = token =>
    new Promise((resolve, reject) => {
    jwt.verify(token, SECRET_KEY, (err, payload) => {
        if (err) return reject(err);
        resolve(payload);
    });
  });

  payload = await verifyToken(token);
  // console.log(req);
  // User.findByPk(id)
  //   .then(data => {
  //     if (data) {
        res.send({origin_token: token, verify_data: {HCP: payload.HCP, UserID: payload.UserID}}); // data);
  //     } else {
  //       res.status(404).send({
  //         message: `Cannot find with id=${id}.`
  //       });
  //     }
  //   })
  //   .catch(err => {
  //     res.status(500).send({
  //       message: "Error retrieving with id=" + id
  //     });
  //   });
};

// Validate Login Api
// exports.validateLogin = (req, res) => {
//   const email = req.body.email;
//   const password = req.body.password;
//   console.error("Login Email Password"+" "+email+" "+password)
//   const user = User.findOne({
//     where: {
//       email: email,
//       password: password
//     }
//   });
//   if(!user){
//     res.status(402).json({
//         success: false
//     })
//   }else{
//     res.status(200).json({
//         success: true
//     })
//  }
// };

// find all
// exports.findAllPublished = (req, res) => {
//   User.findAll({ where: { published: true } })
//     .then(data => {
//       res.send(data);
//     })
//     .catch(err => {
//       res.status(500).send({
//         message:
//           err.message || "Some error occurred while retrieving."
//       });
//     });
// };


exports.userCheck = (req, res) => {
  const email = req.body.username;
  console.error("EMAIL IS : " + email);
  User.findAll({ where: { email: email, roles: { [Op.not]: 'admin' } } })
    .then(data => {
      console.log("DATA IS THE : " + JSON.stringify(data[0]))
      if (data != "") {
        res.send(JSON.stringify(data[0]));
      } else {
        res.send(false);
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with email=" + email
      });
    });
};

exports.emailLicenceCheck = (req, res) => {
  const email = req.body.username;
  const licenseNumber = req.body.licenseNumber;
  User.findOne({ where: { email: email, roles: { [Op.eq]: 'member' } } })
    .then(data => {
      if (data != "" && data != null) {
        console.log("In Email " + data)
        res.send("Email Already Exists");
      }
      else {
        User.findOne({ where: { licenseNumber: licenseNumber, roles: { [Op.eq]: 'member' } } })
          .then(data => {
            console.log("In LicenseNumber " + data)
            if (data != "" && data != null) {
              console.log("In LicenseNumber " + data)
              res.send("LicenseNumber Already Exists");
            } else {
              console.log("In true")
              res.send(true);
              // User.findOne({ where: { key: key, roles: { [Op.eq]: 'member' } } })
              //   .then(data => {
              //     console.log("In key " + data)
              //     if (data != "" && data != null) {
              //       console.log("In key " + data)
              //       res.send("key Already Exists");
              //     } else {
              //       console.log("In true")
              //       res.send(true);
              //     }
              //   })
              //   .catch(err => {
              //     res.status(500).send({
              //       message: "Error retrieving with email=" + email
              //     });
              //   });
            }
          })
          .catch(err => {
            res.status(500).send({
              message: "Error retrieving with email=" + email
            });
          });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with email=" + email
      });
    });
};

exports.keyCheck = (req, res) => {
  User.findOne({ where: { key: req.body.key, roles: { [Op.eq]: 'member' } } })
    .then(data => {
      console.log("In key " + data)
      if (data != "" && data != null) {
        res.send(false);
      } else {
        console.log("In true")
        res.send(true);
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with email=" + email
      });
    });
};

exports.loginCounter = (req, res) => {
  // const email = req.body.username;
  // const password = req.body.password;
  console.error("In counter : " + req.body.loginCount + " " + req.body.id)
  User.update({ loginCount: req.body.loginCount }, { where: { id: req.body.id, roles: { [Op.not]: 'admin' } } })
    .then(data => {
      console.log("DATA IS THE : " + data)
      if (data != "") {
        res.send(true);
      } else {
        res.send(false);
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with email=" + req.body.id
      });
    });
};

//For Email Sent
const transporter = nodemailer.createTransport({
  port: process.env.MailPort,               // true for 465, false for other ports
  host: process.env.Host,
  auth: {
    user: process.env.Mail,
    pass: process.env.Password,
  },
  secure: true,
});

exports.emailSent = (req, res) => {
  // const email = req.body.username;
  // const password = req.body.password;
  console.error("In counter : " + req.body.password + " " + req.body.id + " " + process.env.Host)

  // 메일전송 API (구현 참조 : was2.zplab.co.kr/server/api/MetaverseUser/contactus/contactus.ctrl.js)
  // 4. 로그인 5회 실패 시 -> 사용자에게 임시비밀번호 메일로 발송됨 
  // 5. 비밀번호 찾기 시 -> 사용자에게 임시비밀번호 메일로 발송됨
  // https://github.com/predict-interactive/Gilead-HCP-front/issues/2#issuecomment-1341947564
  const sendMail = () => {
    axios.post(MAILCON.url, {
      apiKey: MAILCON.apiKey,
      gubun: "Temppw",
      data: {
        receiveEmail: req.body.email,
        managerEmail: MAILCON.managerEmail,
        tempPw: req.body.password
      }
    }).then((res) => {
      console.log(res.data)
      console.log('메일전송완료');
    })
  }

  //NEET TO CHECK
  User.update({ password: passwordEncDescService.encryptRequest(req.body.password) }, { where: { id: req.body.id, roles: { [Op.not]: 'admin' } } })
    .then(data => {
      console.log("DATA IS THE : " + data)
      if (data != "") {
        let to = req.body.email;
        let subject = "Password Reset";
        let text = "Password is : " + req.body.password;
        // const { to, subject, text } = req.body;
        console.log("Before Error")
        res.status(200).send({ message: "Mail send", message_id: "info.messageId" });
        sendMail(); // 4. 로그인 5회 실패 시 / 5. 비밀번호 찾기 시

        /* 기존 이메일 발송 로직 
        const mailData = {
          from: process.env.Mail,
          to: to,
          subject: subject,
          text: text,
          html: '<b>Hey there! </b><br> ' + text + '<br/>',
        };

        transporter.sendMail(mailData, (error, info) => {
          if (error) {
            return console.log(error);
          }
          res.status(200).send({ message: "Mail send", message_id: info.messageId });
        });
        // */
        // res.send(true);
      } else {
        res.send(false);
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with email=" + req.body.email
      });
    });
};

exports.findId = (req, res) => {
  const username = req.body.username;
  const licenseNumber = req.body.licenseNumber;
  User.findAll({ where: { name: username, licenseNumber: licenseNumber, roles: { [Op.not]: 'admin' } } })
    .then(data => {
      console.log("DATA IS THE : " + JSON.stringify(data[0]))
      if (data != "") {
        res.send(JSON.stringify(data[0]));
      } else {
        res.send(false);
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with email=" + username
      });
    });
};

exports.findPassword = (req, res) => {
  const username = req.body.username;
  const email = req.body.email;
  User.findAll({ where: { name: username, email: email, roles: { [Op.not]: 'admin' } } })
    .then(data => {
      console.log("DATA IS THE : " + JSON.stringify(data[0]))
      if (data != "") {
        res.send(JSON.stringify(data[0]));
      } else {
        res.send(false);
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with email=" + email
      });
    });
};

exports.memberLoginPage = (req, res) => {
  const email = req.body.username;
  // const password = req.body.password;
  User.findOne({ where: { email: email, password: passwordEncDescService.encryptRequest(req.body.password), roles: { [Op.eq]: 'member' } } })
    .then(data => {
      if (data != "") {
        res.send(data);
      } else {
        res.send(false);
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving with email=" + email
      });
    });
};
