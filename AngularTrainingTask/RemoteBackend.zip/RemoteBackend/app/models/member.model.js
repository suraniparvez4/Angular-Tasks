module.exports = (sequelize, Sequelize) => {
  const Member = sequelize.define("user", {
    name: {
      type: Sequelize.STRING
    },
    email: {
      type: Sequelize.STRING
    },
    password: {
      type: Sequelize.STRING
    },
    birth: {
      type: Sequelize.DATEONLY
    },
    licenseType: {
      type: Sequelize.STRING
    },
    licenseNumber: {
      type: Sequelize.STRING
    },
    hcpApproval: {
      type: Sequelize.STRING
    },
    loginCount: {
      type: Sequelize.INTEGER,
      defaultValue: 0,
    },
    roles: {
      type: Sequelize.STRING,
      default: 'member',
    },
    isFullyAgree: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
    isTermsandConditions: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
    isUseofPersonalInfo: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
    isProcessPersonalInfo: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
    isDeliveringMedicalAndPharmaceuticalInfo: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
  });

  return Member;
};
