module.exports = (sequelize, Sequelize) => {
  const User = sequelize.define("user", {
    id: {
      type: Sequelize.MEDIUMINT,
      primaryKey: true
    },
    name: {
      type: Sequelize.STRING
    },
    email: {
      type: Sequelize.STRING
    },
    password: {
      type: Sequelize.STRING
    },
    birth: {
      type: Sequelize.STRING
    },
    licenseType: {
      type: Sequelize.STRING
    },
    licenseNumber: {
      type: Sequelize.STRING
    },
    hcpApproval: {
      type: Sequelize.STRING
    },
    roles: {
      type: Sequelize.STRING,
      default: 'member',
    },
    loginCount: {
      type: Sequelize.INTEGER,
      defaultValue: 0,
    },
    isFullyAgree: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
    isTermsandConditions: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
    isUseofPersonalInfo: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
    isProcessPersonalInfo: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
    isDeliveringMedicalAndPharmaceuticalInfo: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
  });
  return User;
};
