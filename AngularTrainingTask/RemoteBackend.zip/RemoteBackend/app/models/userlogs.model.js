module.exports = (sequelize, Sequelize) => {
    const userLogs = sequelize.define("userlogs", {
        userPK: Sequelize.INTEGER,
        level: Sequelize.STRING,
        datetime: Sequelize.DATE
    },
        {
            timestamps: false,
            createdAt: false,
            updatedAt: false,
        });
    return userLogs;
};
