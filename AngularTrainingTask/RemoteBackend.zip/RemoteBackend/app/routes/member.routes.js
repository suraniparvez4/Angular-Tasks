const passport = require("passport");

module.exports = app => {
  const members = require("../controllers/member.controller.js");

  var router = require("express").Router();

  const authMiddleware = (req, res, next) => {
    console.error("Check in authMiddleware : " + req.user);
    if (!req.isAuthenticated()) {
      console.log('401');
      res.status(401).send('You are not authenticated')
    } else {
      console.log('next middleware');
      return next()
    }
  }

  const checkIsInRole = (role) => (req, res, next) => {
    console.error("Check in checkIsInRole Admin");
    if (!req.user) {
      res.status(401).send('You are not authenticated')
    }

    if (req.user.roles === role) {
      return next();
    }
    else {
      res.status(401).send('You are not authenticated')
    }
  }

  // Create
  // router.post("/", members.create);

  // 회원가입통계
  router.get('/signUpCount', members.signUpCount);

  // 회원로그인통계
  router.get('/logInCount', members.logInCount);
  
  // Get all
  router.get("/", members.findAll);

  router.post("/findbyNameDate", members.findbyNameDate);

  // // Retrieve all
  // router.get("/published", members.findAllPublished);

  // Get a single with id
  router.get("/:id", members.findOne);

  // Update with id
  router.put("/:id/:updateType", members.update);

  // Delete with id
  router.delete("/:id", members.delete);

  // Delete all
  router.delete("/", members.deleteAll);

  app.use('/api/members', authMiddleware, checkIsInRole('admin'), router);
};
