module.exports = app => {
  const users = require("../controllers/user.controller.js");
  const members = require("../controllers/member.controller.js");

  var router = require("express").Router();

  const authMiddleware = (req, res, next) => {
    console.error("Check in authMiddleware:member : " + req.user);
    if (!req.isAuthenticated()) {
      console.log('401');
      res.status(401).send('You are not authenticated')
    } else {
      console.log('next middleware');
      return next()
    }
  }

  const checkIsInRole = (role) => (req, res, next) => {
    console.error("Check in checkIsInRole:member");
    if (!req.user) {
      res.status(401).send('You are not authenticated')
    }

    if (req.user.roles === role) {
      return next();
    }
    else {
      res.status(401).send('You are not authenticated')
    }
  }

  // Create
  router.post("/", users.create);

  // Update my id
  // router.get // for test
  router.put
  ("/updatePW", users.updateByMyID);

  // Delete my id
  // router.get // for test
  router.delete
  ("/cancelMembership/:id", users.deleteByMyID);

  //User Check
  router.post("/userCheck", users.userCheck);

  //Email LicenseNumber Check
  router.post("/emailLicenceCheck", users.emailLicenceCheck);

  //Key Check
  router.post("/keyCheck", users.keyCheck);

  //User Login Counter
  router.post("/loginCounter", users.loginCounter);

  //Email Sent
  router.post("/emailSent", users.emailSent);

  //Find Id
  router.post("/findId", users.findId);

  //Find Id
  router.post("/findPassword", users.findPassword);

  // Get all
  router.get("/", authMiddleware, checkIsInRole('member'), users.findAll);

  // // Retrieve all
  // router.get("/published", users.findAllPublished);

  // Test after Login
  router.get("/testAfterLogin", users.testAfterLogin);
  router.post("/testAfterLogin", users.testAfterLogin);

  // Get a single with id
  router.get("/:id", users.findOne);

  // Update with id
  router.put("/:id", users.update);

  // Delete with id
  router.delete("/:id", users.delete);

  // Delete all
  router.delete("/", users.deleteAll);

  // Validate Login
  // router.get("/users/validateLogin", users.validateLogin);

  // Member Login Page
  router.post("/memberLoginPage", authMiddleware, checkIsInRole('member'), users.memberLoginPage);

  app.use('/api/users', router);
};
