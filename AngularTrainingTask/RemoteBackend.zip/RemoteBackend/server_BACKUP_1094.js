const express = require("express");
const cors = require("cors");
const app = express();
const cookieSession = require('cookie-session');
const passport = require('passport');
const bodyParser = require('body-parser');
const db = require("./app/models");
const LocalStrategy = require('passport-local').Strategy;
var nodemailer = require('nodemailer');
const User = db.users;
var corsOptions = {
<<<<<<< HEAD
  origin: "http://localhost:6080,http://localhost:6081,http://localhost:6082"
=======
  origin: 'https://www.logintoaskgileadmedical.co.kr', //'https://www.logintoaskgileadmedical.co.kr'
  optionsSuccessStatus: 200, // For legacy browser support
  methods: "*",
  credentials:true
>>>>>>> 390802504927641589e42329fc52b639bf3b41eb
};
// app.use(function (req, res, next) {
//   res.header("Access-Control-Allow-Credentials", true);
//   res.header("Access-Control-Allow-Origin", "https://www.logintoaskgileadmedical.co.kr");
//   res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//   next();
// });
//For Productive Env
// const publicRoot = '../MemberManagement/dist'

// app.use(express.static(publicRoot))

// app.get("/", (req, res, next) => {
//   res.sendFile("index.html", { root: publicRoot })
// })

app.use(bodyParser.json());

app.use(cookieSession({
  name: 'hcpsession',
  keys: ['airblahfudwgobl'],
  maxAge: 24 * 60 * 60 * 1000 //24hours
}))

app.use(passport.initialize());

app.use(passport.session());

app.use(cors(corsOptions));

// parse requests of content-type - application/json
app.use(express.json());

// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));

db.sequelize.sync()
  .then(() => {
    console.log("Synced db.");
  })
  .catch((err) => {
    console.log("Failed to sync db: " + err.message);
  });

// // drop the table if it already exists
// db.sequelize.sync({ force: true }).then(() => {
//   console.log("Drop and re-sync db.");
// });

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to application." });
});

require("./app/routes/member.routes")(app);
require("./app/routes/user.routes")(app);

passport.use('user', new LocalStrategy(
  async function (username, password, done) {
    try {
      // const userPre = await User.findOne({ where: { email: username } })
      // if (!userPre) {
      //   return done('Incorrect username', false, { message: 'Incorrect username' })
      // }
      console.error('in user');
      const user = await User.findOne({ where: { email: username, password: password } })
      // var roles=JSON.stringify(user.roles)
      if (!user) {
        return done(null, false, { message: 'Incorrect username or password' })
      }
      if (user.roles == 'admin') {
        console.log('checking role');
        return done(null, false, { message: 'Incorrect username or password' })
      }
      return done(null, user);
    } catch (err) {
      return done(err)
    }
  }
))

passport.use('admin', new LocalStrategy(
  async function (username, password, done) {
    try {
      // const userPre = await User.findOne({ where: { email: username } })
      // if (!userPre) {
      //   return done('Incorrect username', false, { message: 'Incorrect username' })
      // }
      const admin = await User.findOne({ where: { email: username, password: password } })
      console.error('inside admin', admin);
      if (!admin) {
        return done(null, false, { message: 'Incorrect username or password' })
      }
      if (admin.roles != 'admin') {
        return done(null, false, { message: 'Incorrect username or password' })
      }
      return done(null, admin);
    } catch (err) {
      return done(err)
    }
  }
))

// passport.use(new LocalStrategy(
//   async (username, password, done) => {
//     try {
//       const userPre = await User.findOne({ where: { email: username } })
//       if (!userPre) {
//         return done('Incorrect username', false, { message: 'Incorrect username' })
//       }
//       console.error('inside admin');
//       const admin = await User.findOne({ where: { email: username, password: password } })
//       const admin = await User.findOne({ where: filter });
//       if (admin) {
//         console.error('admin found');
//         return done(null, admin)
//       }
//       else {
//         return done(null, false, { message: 'Incorrect username or password' })
//       }
//     } catch (err) {
//       console.log(err);
//     }
//   }
// ))


// app.post('/api/login', passport.authenticate('local'), (req, res) => {
//   console.log("Login Request "+req+" "+res);
//   res.status(200).send({message: 'Logged In Successful'})
// });

app.post("/api/login", (req, res, next) => {
  passport.authenticate("user", (err, user, info) => {
    if (err) {
      return next(err);
    }
    if (user) {
      if (user.hcpApproval == 'Approved') {
        //let timeDifference = Math.abs(user.updatedAt.getTime() - user.createdAt.getTime());
        let currentDate = new Date();
        console.log("Current Date is : " + user.updatedAt + " " + currentDate);
        let dateDiff = Math.abs(user.updatedAt - currentDate) / 1000;
        dateDiff /= (60 * 60 * 24);
        console.log("dateDiff is : " + dateDiff + " " + parseInt(dateDiff / 365.25));
        //console.log(Math.abs("dateDiff IS : "+Math.round(dateDiff/365.25)));
        if (dateDiff <= 1) {
          req.logIn(user, err => {
            User.update({ password: req.body.password }, { where: { id: req.body.id } })
              .then(data => {
                console.log("DATA IS THE : " + data)
                res.send("Logged In Successful");
              })
              .catch(err => {
                res.status(500).send({
                  message: "Error retrieving with email=" + req.body.email
                });
              });
          })
        }
        else {
          res.send("Dormant membership over");
          // User.update({ password: req.body.password }, { where: { id: req.body.id } })
          //   .then(data => {
          //     console.log("DATA IS THE : " + data)
          //     res.send("Dormant membership over");
          //   })
          //   .catch(err => {
          //     res.status(500).send({
          //       message: "Error retrieving with email=" + req.body.email
          //     });
          //   });
        }
      }
      else {
        res.send("Checking medical personnel");
      }
    }
    else {
      // return res.status(400).send([user, "can not log in", info]);
      return res.send("Incorrect username or password");
    }
  })(req, res, next);
});

app.post("/api/adminlogin", (req, res, next) => {
  passport.authenticate("admin", (err, admin, info) => {
    if (err) {
      return next(err);
    }
    if (admin) {
      console.log("admin is : " + JSON.stringify(admin))
      if (admin.roles == 'admin') {
        req.logIn(admin, err => {
          User.update({ password: req.body.password }, { where: { name: req.body.username } })
            .then(data => {
              console.log("DATA IS THE : " + data)
              console.log("Logged In Successful");
              res.send("Logged In Successful");
            })
            .catch(err => {
              res.status(500).send({
                message: "Error retrieving with email=" + req.body.email
              });
            });
        })
      }
      else {
        return res.send("Incorrect username or password");
      }
    }
    else {
      // return res.status(400).send([user, "can not log in", info]);
      return res.send("Incorrect username or password");
    }
  })(req, res, next);
});

app.get("/api/logout", (req, res) => {
  req.logOut();

  console.log("logged out");

  return res.send();
});

// app.post("/api/loginCounter", (req, res, next) => {
//   passport.authenticate("local", (err, user, info) => {
//     if (err) {
//       return next(err);
//     }
//     if (!user) {
//       // return res.status(400).send([user, "can not log in", info]);
//       return res.send("Incorrect username or password");
//     }
//     if (user.id) { }
//     if (user.hcpApproval) {
//       //let timeDifference = Math.abs(user.updatedAt.getTime() - user.createdAt.getTime());
//       let dateDiff = Math.abs(user.updatedAt - user.createdAt) / 1000;
//       dateDiff /= (60 * 60 * 24);
//       console.log("dateDiff is : " + dateDiff + " " + parseInt(diff / 365.25));
//       //console.log(Math.abs("dateDiff IS : "+Math.round(dateDiff/365.25)));
//       if (dateDiff >= 2) {
//         req.logIn(user, err => {
//           res.send("Logged In Successful");
//         })
//       }
//       else {
//         res.send("Dormant membership over");
//       }
//     }
//     else {
//       res.send("Checking medical personnel");
//     }
//   })(req, res, next);
// });

passport.serializeUser((user, done) => {
  // if (isUser(user)) {
  //   // serialize user
  // } else if (isSponsor(user)) {
  //   // serialize company
  // }
  console.error('serialize', user.id);
  done(null, user.id);
})

passport.deserializeUser(function (id, done) {
  console.error('deserialize', id);
  User.findByPk(id).then(function (user) { done(null, user); });
});

// set port, listen for requests
const PORT = process.env.PORT || 6501;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
